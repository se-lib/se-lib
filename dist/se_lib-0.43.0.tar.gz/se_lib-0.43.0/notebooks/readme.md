# se-lib notebooks

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/se-lib/se-lib/blob/d4fd2c71985b7a38c688257c7b70b99329634c68/notebooks/se_lib_system_dynamics_modeling_users_guide_and_examples.ipynb)


[![Jupyter Notebook](https://img.shields.io/badge/Jupyter-Notebook-orange?logo=jupyter)](https://github.com/se-lib/se-lib/blob/d4fd2c71985b7a38c688257c7b70b99329634c68/notebooks/se_lib_system_dynamics_modeling_users_guide_and_examples.ipynb)

